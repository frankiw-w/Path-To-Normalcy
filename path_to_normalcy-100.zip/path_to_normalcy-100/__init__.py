import math
import bpy
import numpy as np
from bpy.props import PointerProperty, FloatProperty, EnumProperty, BoolProperty, IntProperty
from bpy.types import PropertyGroup, Panel, Operator
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform

# Per-curve undo cache: curve object name -> {"image_name": str,
# "diff": {(px, py): old_value}}. A sparse diff, not a full image copy, and
# keyed by the curve that produced it rather than the image it touched, so
# each curve's last stroke can be undone independently. Single-step: a new
# stroke or an undo both clear that curve's entry.
_backup_cache = {}
_ramp_clipboard = None  # last-copied ramp Texture, for the Copy/Paste operators

MAX_U_SAMPLES_PER_SPLINE = 4000
MAX_CANDIDATE_PIXELS = 2_000_000
NEAREST_CHUNK = 800  # pixels per batch when vectorizing nearest-curve-point
BBOX_CHUNK_SAMPLES = 100  # centerline samples per local bounding-box chunk


# ---------------------------------------------------------------------------
# Curve sampling
# ---------------------------------------------------------------------------

def get_curve_polylines(curve_obj, depsgraph):
    """Evaluate the curve's geometry and return a list of splines, each a
    list of world-space Vector points, in order along the spline."""
    eval_obj = curve_obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    if mesh is None or not mesh.vertices:
        if mesh is not None:
            eval_obj.to_mesh_clear()
        return []

    mesh.transform(curve_obj.matrix_world)

    adjacency = {}
    for edge in mesh.edges:
        a, b = edge.vertices
        adjacency.setdefault(a, []).append(b)
        adjacency.setdefault(b, []).append(a)

    visited = set()
    polylines = []

    def walk(start):
        chain = [start]
        visited.add(start)
        current, prev = start, None
        while True:
            neighbors = [n for n in adjacency.get(current, []) if n != prev]
            nxt = next((n for n in neighbors if n not in visited), None)
            if nxt is None:
                if neighbors and neighbors[0] == start:
                    chain.append(start)
                break
            chain.append(nxt)
            visited.add(nxt)
            prev, current = current, nxt
        return chain

    for v in mesh.vertices:
        if v.index not in visited and len(adjacency.get(v.index, [])) <= 1:
            polylines.append([mesh.vertices[i].co.copy() for i in walk(v.index)])

    for v in mesh.vertices:
        if v.index not in visited:
            polylines.append([mesh.vertices[i].co.copy() for i in walk(v.index)])

    eval_obj.to_mesh_clear()
    return polylines


def resample_with_arclength(points, spacing):
    """Walk a polyline and return (point, u_distance) pairs spaced evenly by
    arc length."""
    if len(points) < 2 or spacing <= 0:
        return [(p, 0.0) for p in points]

    result = [(points[0], 0.0)]
    total = 0.0
    carry = 0.0
    for a, b in zip(points, points[1:]):
        seg = b - a
        seg_len = seg.length
        if seg_len <= 1e-9:
            continue
        pos = spacing - carry
        while pos < seg_len:
            result.append((a.lerp(b, pos / seg_len), total + pos))
            pos += spacing
        carry = seg_len - (pos - spacing)
        total += seg_len
    return result


def relax_polyline(points, iterations, cyclic):
    """Laplacian smoothing: pull each point toward its neighbors' average,
    repeated `iterations` times. Open curves keep both endpoints pinned;
    cyclic curves (points[0] == points[-1], per get_curve_polylines'
    closing-duplicate convention) wrap around with nothing pinned."""
    if iterations <= 0 or len(points) < 3:
        return points
    pts = [p.copy() for p in points]
    n = len(pts)
    for _ in range(iterations):
        new_pts = [p.copy() for p in pts]
        if cyclic:
            ring_n = n - 1  # exclude the closing duplicate from the ring
            for i in range(ring_n):
                prev_p = pts[(i - 1) % ring_n]
                next_p = pts[(i + 1) % ring_n]
                new_pts[i] = pts[i].lerp((prev_p + next_p) * 0.5, 0.5)
            new_pts[-1] = new_pts[0].copy()  # keep the closing duplicate in sync
        else:
            for i in range(1, n - 1):
                new_pts[i] = pts[i].lerp((pts[i - 1] + pts[i + 1]) * 0.5, 0.5)
        pts = new_pts
    return pts


def relax_polylines_if_enabled(polylines, props):
    if not props.relax_curve:
        return polylines
    result = []
    for sp in polylines:
        cyclic = len(sp) >= 3 and (sp[0] - sp[-1]).length < 1e-6
        result.append(relax_polyline(sp, props.relax_iterations, cyclic))
    return result


# ---------------------------------------------------------------------------
# Mesh <-> UV lookups, both directions
# ---------------------------------------------------------------------------

def build_uv_lookup(depsgraph, target_obj):
    eval_obj = target_obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    if mesh is None:
        return None, None
    uv_layer = mesh.uv_layers.active
    if uv_layer is None:
        eval_obj.to_mesh_clear()
        return None, None

    mesh.calc_loop_triangles()
    mat = target_obj.matrix_world

    flat_verts = []
    tri_index_lists = []
    tri_data = []
    for tri in mesh.loop_triangles:
        co = [mat @ mesh.vertices[i].co for i in tri.vertices]
        uv = [uv_layer.data[li].uv.copy() for li in tri.loops]
        base = len(flat_verts)
        flat_verts.extend(co)
        tri_index_lists.append([base, base + 1, base + 2])
        tri_data.append((co[0], co[1], co[2], uv[0], uv[1], uv[2]))

    eval_obj.to_mesh_clear()

    if not tri_data:
        return None, None

    bvh = BVHTree.FromPolygons(flat_verts, tri_index_lists, all_triangles=True)
    return bvh, tri_data


def build_uv_space_bvh(tri_data):
    flat = []
    tris = []
    for co0, co1, co2, uv0, uv1, uv2 in tri_data:
        base = len(flat)
        flat.append(Vector((uv0.x, uv0.y, 0.0)))
        flat.append(Vector((uv1.x, uv1.y, 0.0)))
        flat.append(Vector((uv2.x, uv2.y, 0.0)))
        tris.append([base, base + 1, base + 2])
    if not tris:
        return None
    return BVHTree.FromPolygons(flat, tris, all_triangles=True)


def world_to_uv(bvh, tri_data, point):
    location, normal, index, distance = bvh.find_nearest(point)
    if index is None:
        return None, None, None
    co0, co1, co2, uv0, uv1, uv2 = tri_data[index]
    uv_pt = barycentric_transform(
        location, co0, co1, co2,
        Vector((uv0.x, uv0.y, 0.0)),
        Vector((uv1.x, uv1.y, 0.0)),
        Vector((uv2.x, uv2.y, 0.0)),
    )
    return uv_pt.x, uv_pt.y, normal


def uv_to_world(uv_bvh, tri_data, u, v):
    origin = Vector((u, v, 1.0))
    direction = Vector((0.0, 0.0, -1.0))
    location, normal, index, distance = uv_bvh.ray_cast(origin, direction, 2.0)
    if index is None:
        return None
    co0, co1, co2, uv0, uv1, uv2 = tri_data[index]
    world_pt = barycentric_transform(
        location,
        Vector((uv0.x, uv0.y, 0.0)), Vector((uv1.x, uv1.y, 0.0)), Vector((uv2.x, uv2.y, 0.0)),
        co0, co1, co2,
    )
    return world_pt


# ---------------------------------------------------------------------------
# Image sampling / writing
# ---------------------------------------------------------------------------

def load_image_array(image):
    w, h = image.size
    buf = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(buf)
    return buf.reshape(h, w, 4), w, h


def store_image_array(image, arr):
    image.pixels.foreach_set(arr.reshape(-1))
    image.update()


def sample_bilinear(arr, w, h, u, v, channel=0):
    u = min(max(u, 0.0), 1.0)
    v = min(max(v, 0.0), 1.0)
    x = u * (w - 1)
    y = v * (h - 1)
    x0 = int(math.floor(x))
    y0 = int(math.floor(y))
    x1 = min(x0 + 1, w - 1)
    y1 = min(y0 + 1, h - 1)
    fx = x - x0
    fy = y - y0
    c00 = arr[y0, x0, channel]
    c10 = arr[y0, x1, channel]
    c01 = arr[y1, x0, channel]
    c11 = arr[y1, x1, channel]
    top = c00 + (c10 - c00) * fx
    bottom = c01 + (c11 - c01) * fx
    return top + (bottom - top) * fy


def sample_colorramp(ramp, t):
    """Evaluate a ColorRamp at t in [0,1], returning (height, coverage)
    from the color's R and A channels, same convention as image profiles,
    so both sources behave identically downstream."""
    t = min(max(t, 0.0), 1.0)
    color = ramp.evaluate(t)
    return color[0], color[3]


def sample_profile(props, u_norm, v_norm, profile_arr, pw, ph, ramp):
    """Unified profile lookup across both sources (Image, Ramp). Always
    returns (height, coverage): coverage is 1.0 wherever there's no real
    alpha data to say otherwise, or when props.use_alpha is off, so callers
    don't need to special-case any of that. Direction is applied once here,
    after either source produces its raw 0..1 value, so both sources get
    consistent Raise/Indent behavior for free."""
    v_pos = (v_norm + 1.0) * 0.5
    height = None
    coverage = 1.0

    if props.profile_source == 'IMAGE' and profile_arr is not None:
        if props.profile_rotate_90:
            sample_u, sample_v = v_pos, u_norm
        else:
            sample_u, sample_v = u_norm, v_pos
        height = sample_bilinear(profile_arr, pw, ph, sample_u, sample_v, channel=0)
        if props.use_alpha:
            coverage = sample_bilinear(profile_arr, pw, ph, sample_u, sample_v, channel=3)
    elif props.profile_source == 'RAMP' and ramp is not None:
        t = min(abs(v_norm), 1.0) if props.ramp_mapping == 'MIRROR' else v_pos
        height, coverage = sample_colorramp(ramp, t)
        if not props.use_alpha:
            coverage = 1.0

    if height is None:
        # Nothing valid to sample from, a safe no-op rather than a guess.
        return 0.5, 0.0

    if props.profile_direction == 'RAISE':
        height = 0.5 + 0.5 * height
    elif props.profile_direction == 'INDENT':
        height = 0.5 - 0.5 * height

    return height, coverage


def blend_value(old, sampled, strength, mode, direction):
    delta = (sampled - 0.5) * strength
    new_val = old + delta
    if mode == 'MIX':
        mixed = old + (sampled - old) * strength
        if direction == 'RAISE':
            return max(old, mixed)
        elif direction == 'INDENT':
            return min(old, mixed)
        return mixed
    elif mode == 'ADD':
        return new_val
    elif mode == 'MAX':
        return max(old, new_val)
    elif mode == 'MIN':
        return min(old, new_val)
    elif mode == 'AVERAGE':
        return (old + new_val) / 2.0
    elif mode == 'DEVIATION':
        return new_val if abs(new_val - 0.5) > abs(old - 0.5) else old
    return old


def box_blur_1d(a, radius):
    if radius <= 0:
        return a.copy()
    k = radius * 2 + 1
    padded = np.pad(a, radius, mode='edge')
    csum = np.concatenate(([0.0], np.cumsum(padded)))
    return (csum[k:] - csum[:-k]) / k


def box_blur(arr2d, radius):
    """Separable box blur, no scipy dependency, verified against a point
    spike (spreads evenly across the kernel) and a uniform field (stays
    exactly flat, confirming no edge artifacts from the padding mode)."""
    if radius <= 0:
        return arr2d.copy()
    h = np.apply_along_axis(lambda row: box_blur_1d(row, radius), 1, arr2d)
    v = np.apply_along_axis(lambda col: box_blur_1d(col, radius), 0, h)
    return v


def smoothstep(edge0, edge1, x):
    if edge0 == edge1:
        return 0.0 if x < edge0 else 1.0
    t = (x - edge0) / (edge1 - edge0)
    t = min(max(t, 0.0), 1.0)
    return t * t * (3.0 - 2.0 * t)


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class CURVEPAINT_OT_stroke(Operator):
    bl_idname = "paint.curve_stroke"
    bl_label = "Paint Stroke From Curve"
    bl_description = "Write profile detail into the target image along the active curve"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        curve_obj = context.active_object
        if curve_obj is None or curve_obj.type != 'CURVE':
            return False
        props = curve_obj.curve_paint_settings
        if props.target_obj is None or props.target_image is None:
            return False
        if props.profile_source == 'IMAGE' and props.profile_image is None:
            return False
        if props.profile_source == 'RAMP' and props.profile_ramp_texture is None:
            return False
        return True

    def execute(self, context):
        curve_obj = context.active_object
        props = curve_obj.curve_paint_settings
        target_obj = props.target_obj
        target_image = props.target_image

        if target_obj.type != 'MESH':
            self.report({'ERROR'}, "Target field must be a mesh object")
            return {'CANCELLED'}
        if target_image.colorspace_settings.name != 'Non-Color':
            self.report(
                {'WARNING'},
                "Target image color space isn't Non-Color, so values may be gamma-shifted",
            )

        depsgraph = context.evaluated_depsgraph_get()

        polylines = get_curve_polylines(curve_obj, depsgraph)
        if not polylines:
            self.report({'ERROR'}, "Curve has no evaluated points")
            return {'CANCELLED'}
        polylines = relax_polylines_if_enabled(polylines, props)

        bvh, tri_data = build_uv_lookup(depsgraph, target_obj)
        if bvh is None:
            self.report({'ERROR'}, "Target mesh has no active UV map")
            return {'CANCELLED'}
        uv_bvh = build_uv_space_bvh(tri_data)
        if uv_bvh is None:
            self.report({'ERROR'}, "Could not build a UV-space lookup for the target mesh")
            return {'CANCELLED'}

        profile_arr = pw = ph = None
        if props.profile_source == 'IMAGE':
            if props.profile_image is None:
                self.report({'ERROR'}, "No profile image assigned")
                return {'CANCELLED'}
            if props.profile_image.colorspace_settings.name != 'Non-Color':
                self.report(
                    {'WARNING'},
                    "Profile image color space isn't Non-Color, so sampled values may be gamma-shifted",
                )
            profile_arr, pw, ph = load_image_array(props.profile_image)

        ramp = None
        if props.profile_source == 'RAMP':
            if props.profile_ramp_texture is None:
                self.report({'ERROR'}, "No color ramp set up yet, add one first")
                return {'CANCELLED'}
            ramp = props.profile_ramp_texture.color_ramp

        target_arr, tw, th = load_image_array(target_image)

        spacing = max(props.resample_distance, 0.0001)
        half_width = max(props.profile_half_width, 0.0001)
        feather = half_width * props.edge_feather

        stamp_size = max(props.profile_stamp_size, 0.0001)
        if props.profile_mode == 'STAMP' and props.profile_lock_stamp_ratio and pw and ph:
            stamp_size = max(2.0 * half_width * (pw / ph), 0.0001)

        quality = max(1, int(props.profile_quality))
        if quality <= 1:
            sub_offsets = [(0.0, 0.0)]
        else:
            step = 1.0 / quality
            start_off = -0.5 + step / 2.0
            sub_offsets = [
                (start_off + i * step, start_off + j * step)
                for i in range(quality) for j in range(quality)
            ]

        touched = 0
        stroke_diff = {}  # (px, py) -> value before this stroke touched it

        for spline_points in polylines:
            if len(spline_points) < 2:
                continue

            spline_length = sum((b - a).length for a, b in zip(spline_points, spline_points[1:]))
            eff_spacing = spacing
            if spline_length > 0:
                eff_spacing = max(spacing, spline_length / MAX_U_SAMPLES_PER_SPLINE)

            samples = resample_with_arclength(spline_points, eff_spacing)
            if len(samples) < 2:
                continue
            total_length = samples[-1][1]

            centers = []
            u_dists = []
            sides = []
            tangents = []
            point_uv_min = []
            point_uv_max = []
            prev_side = None
            uv_min = Vector((math.inf, math.inf))
            uv_max = Vector((-math.inf, -math.inf))

            for i, (point, u_dist) in enumerate(samples):
                prev_pt = samples[i - 1][0] if i > 0 else point
                next_pt = samples[i + 1][0] if i < len(samples) - 1 else point
                tangent = next_pt - prev_pt
                if tangent.length <= 1e-9:
                    continue
                tangent.normalize()

                u0, v0, normal = world_to_uv(bvh, tri_data, point)
                if normal is None:
                    continue

                if prev_side is None:
                    side = tangent.cross(normal)
                else:
                    side = prev_side - tangent * prev_side.dot(tangent)
                    side = side - normal * side.dot(normal)
                    if side.length <= 1e-9:
                        side = tangent.cross(normal)
                if side.length <= 1e-9:
                    continue
                side.normalize()
                prev_side = side

                centers.append(point)
                u_dists.append(u_dist)
                sides.append(side)
                tangents.append(tangent)

                p_min = Vector((u0, v0))
                p_max = Vector((u0, v0))
                uv_min.x = min(uv_min.x, u0)
                uv_max.x = max(uv_max.x, u0)
                uv_min.y = min(uv_min.y, v0)
                uv_max.y = max(uv_max.y, v0)
                for sign in (-1.0, 1.0):
                    eu, ev, _ = world_to_uv(bvh, tri_data, point + side * (half_width * sign))
                    if eu is not None:
                        p_min.x = min(p_min.x, eu)
                        p_max.x = max(p_max.x, eu)
                        p_min.y = min(p_min.y, ev)
                        p_max.y = max(p_max.y, ev)
                        uv_min.x = min(uv_min.x, eu)
                        uv_max.x = max(uv_max.x, eu)
                        uv_min.y = min(uv_min.y, ev)
                        uv_max.y = max(uv_max.y, ev)
                point_uv_min.append(p_min)
                point_uv_max.append(p_max)

            if len(centers) < 2 or uv_min.x > uv_max.x:
                continue

            if props.cap_style == 'ROUND':
                # The straight-body probing above only accounts for
                # sideways width, not the disc-shaped overhang a round cap
                # needs past the very first/last point, expand the bbox to
                # cover that disc explicitly, in several directions around
                # each tip, so the scan region isn't clipped there.
                for idx, tan_sign in ((0, -1.0), (len(centers) - 1, 1.0)):
                    tip_point = centers[idx]
                    tip_tangent = tangents[idx] * tan_sign
                    tip_side = sides[idx]
                    for angle_deg in range(0, 360, 30):
                        a = math.radians(angle_deg)
                        offset = (tip_tangent * math.cos(a) + tip_side * math.sin(a)) * half_width
                        cu, cv, _ = world_to_uv(bvh, tri_data, tip_point + offset)
                        if cu is not None:
                            uv_min.x = min(uv_min.x, cu)
                            uv_max.x = max(uv_max.x, cu)
                            uv_min.y = min(uv_min.y, cv)
                            uv_max.y = max(uv_max.y, cv)
                            point_uv_min[idx].x = min(point_uv_min[idx].x, cu)
                            point_uv_max[idx].x = max(point_uv_max[idx].x, cu)
                            point_uv_min[idx].y = min(point_uv_min[idx].y, cv)
                            point_uv_max[idx].y = max(point_uv_max[idx].y, cv)
            else:  # FLAT
                # Flat's feather zone genuinely extends candidate pixels past
                # the tip (see the within/edge_dist logic below), so the scan
                # region needs to reach that far too, or the taper just gets
                # cut off outside the bounding box, worse the larger
                # edge_feather is, since more of the taper falls outside it.
                for idx, tan_sign in ((0, -1.0), (len(centers) - 1, 1.0)):
                    tip_point = centers[idx]
                    tip_tangent = tangents[idx] * tan_sign
                    tip_side = sides[idx]
                    for width_sign in (-1.0, 1.0):
                        offset = tip_tangent * feather + tip_side * (half_width * width_sign)
                        cu, cv, _ = world_to_uv(bvh, tri_data, tip_point + offset)
                        if cu is not None:
                            uv_min.x = min(uv_min.x, cu)
                            uv_max.x = max(uv_max.x, cu)
                            uv_min.y = min(uv_min.y, cv)
                            uv_max.y = max(uv_max.y, cv)
                            point_uv_min[idx].x = min(point_uv_min[idx].x, cu)
                            point_uv_max[idx].x = max(point_uv_max[idx].x, cu)
                            point_uv_min[idx].y = min(point_uv_min[idx].y, cv)
                            point_uv_max[idx].y = max(point_uv_max[idx].y, cv)

            # Build small per-chunk boxes instead of one box covering the
            # whole spline's extent. A single box around, say, a large
            # circle would mostly cover empty interior; many small boxes
            # hugging the actual path avoid scanning all of that wasted
            # area, at the cost of a small amount of overlap between
            # neighboring chunks (deduplicated below).
            margin_px = 2
            chunk_boxes = []
            n_pts = len(centers)
            for chunk_start in range(0, n_pts, BBOX_CHUNK_SAMPLES):
                chunk_end = min(chunk_start + BBOX_CHUNK_SAMPLES, n_pts)
                c_min = Vector((math.inf, math.inf))
                c_max = Vector((-math.inf, -math.inf))
                for i in range(chunk_start, chunk_end):
                    c_min.x = min(c_min.x, point_uv_min[i].x)
                    c_min.y = min(c_min.y, point_uv_min[i].y)
                    c_max.x = max(c_max.x, point_uv_max[i].x)
                    c_max.y = max(c_max.y, point_uv_max[i].y)
                if c_min.x > c_max.x:
                    continue
                cbx0 = max(int(math.floor(c_min.x * tw)) - margin_px, 0)
                cbx1 = min(int(math.ceil(c_max.x * tw)) + margin_px, tw - 1)
                cby0 = max(int(math.floor(c_min.y * th)) - margin_px, 0)
                cby1 = min(int(math.ceil(c_max.y * th)) + margin_px, th - 1)
                if cbx0 <= cbx1 and cby0 <= cby1:
                    chunk_boxes.append((cbx0, cbx1, cby0, cby1))

            if not chunk_boxes:
                continue

            total_box_area = sum((b[1] - b[0] + 1) * (b[3] - b[2] + 1) for b in chunk_boxes)
            if total_box_area * len(sub_offsets) > MAX_CANDIDATE_PIXELS:
                self.report(
                    {'WARNING'},
                    "Skipped a spline, its bounding region covers too many pixels",
                )
                continue

            pixel_coords = []
            pixel_positions = []
            subsample_count = {}  # (px, py) -> how many sub-samples found valid geometry
            processed_pixels = set()
            for cbx0, cbx1, cby0, cby1 in chunk_boxes:
                for py in range(cby0, cby1 + 1):
                    for px in range(cbx0, cbx1 + 1):
                        coord = (px, py)
                        if coord in processed_pixels:
                            continue
                        processed_pixels.add(coord)
                        for ox, oy in sub_offsets:
                            u = (px + 0.5 + ox) / tw
                            v = (py + 0.5 + oy) / th
                            world_pt = uv_to_world(uv_bvh, tri_data, u, v)
                            if world_pt is None:
                                continue
                            pixel_coords.append(coord)
                            pixel_positions.append((world_pt.x, world_pt.y, world_pt.z))
                            subsample_count[coord] = subsample_count.get(coord, 0) + 1

            if not pixel_positions:
                continue

            centers_arr = np.array([(p.x, p.y, p.z) for p in centers], dtype=np.float64)
            sides_arr = np.array([(s.x, s.y, s.z) for s in sides], dtype=np.float64)
            tangents_arr = np.array([(t.x, t.y, t.z) for t in tangents], dtype=np.float64)
            u_arr = np.array(u_dists, dtype=np.float64)
            pos_arr = np.array(pixel_positions, dtype=np.float64)
            n_centers = len(centers)

            seg_start = centers_arr[:-1]
            seg_end = centers_arr[1:]
            seg_vec = seg_end - seg_start
            seg_len_sq = np.maximum(np.sum(seg_vec * seg_vec, axis=1), 1e-12)
            n_segs = len(seg_start)

            pixel_accum = {}  # (px, py) -> [weighted_sample_sum, weight_sum]
            for start in range(0, len(pos_arr), NEAREST_CHUNK):
                chunk_pos = pos_arr[start:start + NEAREST_CHUNK]
                chunk_coords = pixel_coords[start:start + NEAREST_CHUNK]

                # Nearest point on the nearest SEGMENT, not just nearest
                # sample, makes curve position a genuinely continuous
                # value instead of quantized to a fixed set of discrete
                # sample positions. Stamp mode needs this specifically:
                # its position value has to vary smoothly within a single
                # small repeat cycle, and snapping to samples was
                # quantizing that into a visible staircase.
                diff_all = chunk_pos[:, None, :] - seg_start[None, :, :]
                t_raw = np.einsum('mnk,nk->mn', diff_all, seg_vec) / seg_len_sq[None, :]
                t_clamped = np.clip(t_raw, 0.0, 1.0)
                proj = seg_start[None, :, :] + t_clamped[:, :, None] * seg_vec[None, :, :]
                dist_sq_seg = np.sum((chunk_pos[:, None, :] - proj) ** 2, axis=2)
                best_seg = np.argmin(dist_sq_seg, axis=1)
                idx = np.arange(len(chunk_pos))
                nearest_dist = np.sqrt(dist_sq_seg[idx, best_seg])
                best_t = t_clamped[idx, best_seg]
                best_proj = proj[idx, best_seg]

                u_at_pixel = u_arr[best_seg] + best_t * (u_arr[best_seg + 1] - u_arr[best_seg])

                side_interp = sides_arr[best_seg] + best_t[:, None] * (sides_arr[best_seg + 1] - sides_arr[best_seg])
                side_interp /= np.maximum(np.linalg.norm(side_interp, axis=1, keepdims=True), 1e-9)

                nearest_diff = chunk_pos - best_proj
                v_signed = np.einsum('mk,mk->m', nearest_diff, side_interp)

                if props.cap_style == 'ROUND':
                    within = nearest_dist <= half_width
                    edge_dist = half_width - nearest_dist
                else:  # FLAT
                    tangent_interp = tangents_arr[best_seg] + best_t[:, None] * (
                        tangents_arr[best_seg + 1] - tangents_arr[best_seg]
                    )
                    tangent_interp /= np.maximum(np.linalg.norm(tangent_interp, axis=1, keepdims=True), 1e-9)
                    tangent_signed = np.einsum('mk,mk->m', nearest_diff, tangent_interp)
                    is_start = (best_seg == 0) & (best_t <= 0.0)
                    is_end = (best_seg == (n_segs - 1)) & (best_t >= 1.0)
                    past_start = np.where(is_start, np.maximum(0.0, -tangent_signed), 0.0)
                    past_end = np.where(is_end, np.maximum(0.0, tangent_signed), 0.0)
                    cap_overshoot = past_start + past_end
                    within = (np.abs(v_signed) <= half_width) & (cap_overshoot <= max(feather, 0.0))
                    width_edge_dist = half_width - np.abs(v_signed)
                    length_edge_dist = feather - cap_overshoot
                    edge_dist = np.minimum(width_edge_dist, length_edge_dist)

                for local_i in np.nonzero(within)[0]:
                    v_norm = float(v_signed[local_i] / half_width)
                    u_dist_here = float(u_at_pixel[local_i])
                    if props.profile_mode == 'STAMP' and props.profile_spacing > 0:
                        cycle_pos = u_dist_here % props.profile_spacing
                        if cycle_pos >= stamp_size:
                            continue  # in the gap between stamps, no effect here
                        u_norm = cycle_pos / stamp_size
                    else:
                        u_norm = (u_dist_here / total_length) if total_length > 0 else 0.0

                    sampled, coverage = sample_profile(props, u_norm, v_norm, profile_arr, pw, ph, ramp)

                    if feather <= 0:
                        edge_factor = 1.0
                    else:
                        edge_factor = max(0.0, min(1.0, float(edge_dist[local_i]) / feather))
                    edge_factor *= coverage

                    coord = chunk_coords[local_i]
                    entry = pixel_accum.get(coord)
                    if entry is None:
                        pixel_accum[coord] = [sampled * edge_factor, edge_factor]
                    else:
                        entry[0] += sampled * edge_factor
                        entry[1] += edge_factor

            # Average across every sub-sample generated for each pixel,
            # including ones that never made it into pixel_accum at all
            # (outside the boundary, or in a Stamp gap). Those correctly
            # count as zero-weight rather than being skipped, which is what
            # produces genuine partial coverage: a soft, anti-aliased edge,
            # instead of every pixel being all-or-nothing.
            pixel_writes = {}
            for coord, count in subsample_count.items():
                entry = pixel_accum.get(coord)
                weight_sum = entry[1] if entry is not None else 0.0
                if weight_sum <= 0.0:
                    continue
                avg_sampled = entry[0] / weight_sum
                avg_factor = weight_sum / count
                pixel_writes[coord] = (avg_sampled, avg_factor)

            for (px, py), (sampled, edge_factor) in pixel_writes.items():
                old = target_arr[py, px, 0]
                if (px, py) not in stroke_diff:
                    stroke_diff[(px, py)] = old
                new = blend_value(
                    old, sampled, props.profile_strength * edge_factor, props.blend_mode, props.profile_direction
                )
                target_arr[py, px, 0] = new
                target_arr[py, px, 1] = new
                target_arr[py, px, 2] = new
                touched += 1

        if touched == 0:
            self.report({'WARNING'}, "Nothing written, is the curve near the target mesh's surface?")
            return {'CANCELLED'}

        _backup_cache[curve_obj.name] = {"image_name": target_image.name, "diff": stroke_diff}
        store_image_array(target_image, target_arr)

        self.report({'INFO'}, f"Stroke painted from curve ({touched} texels touched)")

        if props.blur_auto_apply:
            bpy.ops.paint.curve_stroke_blur()

        return {'FINISHED'}


class CURVEPAINT_OT_blur(Operator):
    bl_idname = "paint.curve_stroke_blur"
    bl_label = "Blur Stroke"
    bl_description = "Blur the target image along this curve's painted region"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        curve_obj = context.active_object
        if curve_obj is None or curve_obj.type != 'CURVE':
            return False
        props = curve_obj.curve_paint_settings
        return props.target_obj is not None and props.target_image is not None

    def execute(self, context):
        curve_obj = context.active_object
        props = curve_obj.curve_paint_settings
        target_obj = props.target_obj
        target_image = props.target_image

        if target_obj.type != 'MESH':
            self.report({'ERROR'}, "Target field must be a mesh object")
            return {'CANCELLED'}

        depsgraph = context.evaluated_depsgraph_get()
        polylines = get_curve_polylines(curve_obj, depsgraph)
        if not polylines:
            self.report({'ERROR'}, "Curve has no evaluated points")
            return {'CANCELLED'}
        polylines = relax_polylines_if_enabled(polylines, props)

        bvh, tri_data = build_uv_lookup(depsgraph, target_obj)
        if bvh is None:
            self.report({'ERROR'}, "Target mesh has no active UV map")
            return {'CANCELLED'}
        uv_bvh = build_uv_space_bvh(tri_data)
        if uv_bvh is None:
            self.report({'ERROR'}, "Could not build a UV-space lookup for the target mesh")
            return {'CANCELLED'}

        target_arr, tw, th = load_image_array(target_image)

        spacing = max(props.resample_distance, 0.0001)
        half_width = max(props.profile_half_width, 0.0001)
        blend_margin = max(props.blend_margin, 0.0)
        extended_half_width = half_width + blend_margin

        # This re-derives "which pixels does this curve affect" the same
        # way the paint operator does, duplicated rather than shared with
        # it for now, to avoid risking the paint path while adding this.
        # The candidate region is extended past the stroke's own boundary
        # by blend_margin, so the blur can actually blend into the
        # surrounding pixels instead of stopping dead at the same edge the
        # paint pass produced.
        touched = {}  # (px, py) -> weight
        for spline_points in polylines:
            if len(spline_points) < 2:
                continue
            spline_length = sum((b - a).length for a, b in zip(spline_points, spline_points[1:]))
            eff_spacing = spacing
            if spline_length > 0:
                eff_spacing = max(spacing, spline_length / MAX_U_SAMPLES_PER_SPLINE)
            samples = resample_with_arclength(spline_points, eff_spacing)
            if len(samples) < 2:
                continue

            centers, sides, tangents = [], [], []
            prev_side = None
            uv_min = Vector((math.inf, math.inf))
            uv_max = Vector((-math.inf, -math.inf))
            for i, (point, u_dist) in enumerate(samples):
                prev_pt = samples[i - 1][0] if i > 0 else point
                next_pt = samples[i + 1][0] if i < len(samples) - 1 else point
                tangent = next_pt - prev_pt
                if tangent.length <= 1e-9:
                    continue
                tangent.normalize()
                u0, v0, normal = world_to_uv(bvh, tri_data, point)
                if normal is None:
                    continue
                if prev_side is None:
                    side = tangent.cross(normal)
                else:
                    side = prev_side - tangent * prev_side.dot(tangent)
                    side = side - normal * side.dot(normal)
                    if side.length <= 1e-9:
                        side = tangent.cross(normal)
                if side.length <= 1e-9:
                    continue
                side.normalize()
                prev_side = side
                centers.append(point)
                sides.append(side)
                tangents.append(tangent)
                uv_min.x = min(uv_min.x, u0); uv_max.x = max(uv_max.x, u0)
                uv_min.y = min(uv_min.y, v0); uv_max.y = max(uv_max.y, v0)
                for sign in (-1.0, 1.0):
                    eu, ev, _ = world_to_uv(bvh, tri_data, point + side * (extended_half_width * sign))
                    if eu is not None:
                        uv_min.x = min(uv_min.x, eu); uv_max.x = max(uv_max.x, eu)
                        uv_min.y = min(uv_min.y, ev); uv_max.y = max(uv_max.y, ev)

            if len(centers) < 2 or uv_min.x > uv_max.x:
                continue

            # Round caps already cover their full disc via nearest_dist, so
            # the same corner-probing trick from the paint operator extends
            # naturally to the margin zone just by using the bigger radius.
            for idx, tan_sign in ((0, -1.0), (len(centers) - 1, 1.0)):
                tip_point, tip_tangent, tip_side = centers[idx], tangents[idx] * tan_sign, sides[idx]
                for angle_deg in range(0, 360, 30):
                    a = math.radians(angle_deg)
                    offset = (tip_tangent * math.cos(a) + tip_side * math.sin(a)) * extended_half_width
                    cu, cv, _ = world_to_uv(bvh, tri_data, tip_point + offset)
                    if cu is not None:
                        uv_min.x = min(uv_min.x, cu); uv_max.x = max(uv_max.x, cu)
                        uv_min.y = min(uv_min.y, cv); uv_max.y = max(uv_max.y, cv)

            margin_px = max(2, int(round(props.blur_size)))
            bx0 = max(int(math.floor(uv_min.x * tw)) - margin_px, 0)
            bx1 = min(int(math.ceil(uv_max.x * tw)) + margin_px, tw - 1)
            by0 = max(int(math.floor(uv_min.y * th)) - margin_px, 0)
            by1 = min(int(math.ceil(uv_max.y * th)) + margin_px, th - 1)
            if bx0 > bx1 or by0 > by1:
                continue
            if (bx1 - bx0 + 1) * (by1 - by0 + 1) > MAX_CANDIDATE_PIXELS:
                self.report({'WARNING'}, "Skipped a spline, its bounding region covers too many pixels")
                continue

            pixel_coords, pixel_positions = [], []
            for py in range(by0, by1 + 1):
                v = (py + 0.5) / th
                for px in range(bx0, bx1 + 1):
                    u = (px + 0.5) / tw
                    world_pt = uv_to_world(uv_bvh, tri_data, u, v)
                    if world_pt is None:
                        continue
                    pixel_coords.append((px, py))
                    pixel_positions.append((world_pt.x, world_pt.y, world_pt.z))
            if not pixel_positions:
                continue

            centers_arr = np.array([(p.x, p.y, p.z) for p in centers], dtype=np.float64)
            sides_arr = np.array([(s.x, s.y, s.z) for s in sides], dtype=np.float64)
            tangents_arr = np.array([(t.x, t.y, t.z) for t in tangents], dtype=np.float64)
            pos_arr = np.array(pixel_positions, dtype=np.float64)
            n_centers = len(centers)

            for start in range(0, len(pos_arr), NEAREST_CHUNK):
                chunk_pos = pos_arr[start:start + NEAREST_CHUNK]
                chunk_coords = pixel_coords[start:start + NEAREST_CHUNK]
                diff = chunk_pos[:, None, :] - centers_arr[None, :, :]
                dist_sq = np.einsum('mnk,mnk->mn', diff, diff)
                nearest_idx = np.argmin(dist_sq, axis=1)
                nearest_dist = np.sqrt(dist_sq[np.arange(len(chunk_pos)), nearest_idx])
                nearest_diff = chunk_pos - centers_arr[nearest_idx]
                v_signed = np.einsum('mk,mk->m', nearest_diff, sides_arr[nearest_idx])

                if props.cap_style == 'ROUND':
                    candidate = nearest_dist <= extended_half_width
                    outside_amount = np.maximum(0.0, nearest_dist - half_width)
                else:
                    nearest_tangent = tangents_arr[nearest_idx]
                    tangent_signed = np.einsum('mk,mk->m', nearest_diff, nearest_tangent)
                    is_start = nearest_idx == 0
                    is_end = nearest_idx == (n_centers - 1)
                    past_start = np.where(is_start, np.maximum(0.0, -tangent_signed), 0.0)
                    past_end = np.where(is_end, np.maximum(0.0, tangent_signed), 0.0)
                    cap_overshoot = past_start + past_end
                    width_outside = np.maximum(0.0, np.abs(v_signed) - half_width)
                    outside_amount = np.maximum(width_outside, cap_overshoot)
                    candidate = outside_amount <= blend_margin

                for local_i in np.nonzero(candidate)[0]:
                    outside = float(outside_amount[local_i])
                    if outside <= 0.0:
                        # Inside the core stroke: existing mask-mode behavior.
                        # Edge distance uses true nearest-point distance, not
                        # just the width-direction component. The latter is
                        # blind to how close a pixel is to a cap boundary,
                        # which is what produced the cap artifacts.
                        if props.blur_mask_mode == 'EDGES':
                            edge_frac = min(float(nearest_dist[local_i]) / half_width, 1.0)
                            weight = smoothstep(props.blur_edge_threshold, 1.0, edge_frac)
                        else:
                            weight = 1.0
                    elif blend_margin > 0:
                        # In the margin band: always fades from full effect
                        # at the boundary to none at the outer edge, so the
                        # stroke actually blends into its surroundings
                        # instead of stopping dead at the same edge the
                        # paint pass produced.
                        weight = smoothstep(blend_margin, 0.0, outside)
                    else:
                        weight = 0.0

                    coord = chunk_coords[local_i]
                    prev = touched.get(coord)
                    if prev is None or weight > prev:
                        touched[coord] = weight

        if not touched:
            self.report({'WARNING'}, "Nothing to blur, no painted region found for this curve")
            return {'CANCELLED'}

        radius_px = max(1, int(round(props.blur_size)))

        xs = [p[0] for p in touched]
        ys = [p[1] for p in touched]
        bx0 = max(min(xs) - radius_px, 0)
        bx1 = min(max(xs) + radius_px, tw - 1)
        by0 = max(min(ys) - radius_px, 0)
        by1 = min(max(ys) + radius_px, th - 1)

        region = target_arr[by0:by1 + 1, bx0:bx1 + 1, 0].astype(np.float64)
        blurred = box_blur(region, radius_px)

        for (px, py), weight in touched.items():
            w = weight * props.blur_strength
            if w <= 0.0:
                continue
            lx, ly = px - bx0, py - by0
            old = target_arr[py, px, 0]
            new = old + (float(blurred[ly, lx]) - old) * w
            target_arr[py, px, 0] = new
            target_arr[py, px, 1] = new
            target_arr[py, px, 2] = new

        store_image_array(target_image, target_arr)
        self.report({'INFO'}, f"Blurred {len(touched)} texels")
        return {'FINISHED'}


class CURVEPAINT_OT_undo(Operator):
    bl_idname = "paint.curve_stroke_undo"
    bl_label = "Undo Last Stroke"
    bl_description = (
        "Restore the pixels this curve's last stroke touched (single-step, "
        "specific to the active curve, not tied to Blender's normal undo)"
    )

    @classmethod
    def poll(cls, context):
        curve_obj = context.active_object
        return curve_obj is not None and curve_obj.type == 'CURVE' and curve_obj.name in _backup_cache

    def execute(self, context):
        curve_obj = context.active_object
        entry = _backup_cache.get(curve_obj.name)
        if entry is None:
            self.report({'WARNING'}, "Nothing to undo for this curve")
            return {'CANCELLED'}

        image = bpy.data.images.get(entry["image_name"])
        if image is None:
            del _backup_cache[curve_obj.name]
            self.report({'WARNING'}, "The target image for that stroke no longer exists")
            return {'CANCELLED'}

        arr, w, h = load_image_array(image)
        for (px, py), old_val in entry["diff"].items():
            arr[py, px, 0] = old_val
            arr[py, px, 1] = old_val
            arr[py, px, 2] = old_val
        store_image_array(image, arr)

        del _backup_cache[curve_obj.name]
        self.report({'INFO'}, "Restored this curve's pixels to before its last stroke")
        return {'FINISHED'}


class CURVEPAINT_OT_redraw(Operator):
    bl_idname = "paint.curve_stroke_redraw"
    bl_label = "Redraw"
    bl_description = "Undo this curve's last stroke and immediately repaint it with current settings"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if not CURVEPAINT_OT_stroke.poll(context):
            return False
        curve_obj = context.active_object
        return curve_obj.name in _backup_cache

    def execute(self, context):
        curve_obj = context.active_object
        bpy.ops.paint.curve_stroke_undo()
        return bpy.ops.paint.curve_stroke()


class CURVEPAINT_OT_paint_selected(Operator):
    bl_idname = "paint.curve_stroke_paint_selected"
    bl_label = "Paint Selected Curves"
    bl_description = "Run Draw for every selected curve, using each curve's own settings"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'CURVE' for o in context.selected_objects)

    def execute(self, context):
        curve_objs = [o for o in context.selected_objects if o.type == 'CURVE']
        prev_active = context.view_layer.objects.active
        painted = 0
        skipped = 0
        for curve_obj in curve_objs:
            context.view_layer.objects.active = curve_obj
            try:
                result = bpy.ops.paint.curve_stroke()
            except RuntimeError:
                skipped += 1
                continue
            if 'FINISHED' in result:
                painted += 1
            else:
                skipped += 1
        if prev_active is not None:
            context.view_layer.objects.active = prev_active

        if painted == 0:
            self.report({'WARNING'}, "Nothing painted, check selected curves have valid target/profile settings")
            return {'CANCELLED'}
        msg = f"Painted {painted} curve(s)"
        if skipped:
            msg += f", skipped {skipped} not ready"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class CURVEPAINT_OT_undo_selected(Operator):
    bl_idname = "paint.curve_stroke_undo_selected"
    bl_label = "Undo Selected"
    bl_description = "Undo the last stroke for every selected curve that has one"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'CURVE' and o.name in _backup_cache for o in context.selected_objects)

    def execute(self, context):
        curve_objs = [
            o for o in context.selected_objects if o.type == 'CURVE' and o.name in _backup_cache
        ]
        prev_active = context.view_layer.objects.active
        undone = 0
        for curve_obj in curve_objs:
            context.view_layer.objects.active = curve_obj
            try:
                result = bpy.ops.paint.curve_stroke_undo()
            except RuntimeError:
                continue
            if 'FINISHED' in result:
                undone += 1
        if prev_active is not None:
            context.view_layer.objects.active = prev_active

        if undone == 0:
            self.report({'WARNING'}, "Nothing to undo among selected curves")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Undid {undone} curve(s)")
        return {'FINISHED'}


def create_ramp_texture(curve_obj):
    tex = bpy.data.textures.new(f"{curve_obj.name}_CurvePaintRamp", type='BLEND')
    tex.use_color_ramp = True
    tex.use_fake_user = True
    return tex


class CURVEPAINT_OT_add_ramp(Operator):
    bl_idname = "paint.curve_stroke_add_ramp"
    bl_label = "Add Color Ramp"
    bl_description = "Create a color ramp for this curve's profile"

    @classmethod
    def poll(cls, context):
        curve_obj = context.active_object
        return curve_obj is not None and curve_obj.type == 'CURVE'

    def execute(self, context):
        curve_obj = context.active_object
        props = curve_obj.curve_paint_settings
        props.profile_ramp_texture = create_ramp_texture(curve_obj)
        return {'FINISHED'}


class CURVEPAINT_OT_copy_ramp(Operator):
    bl_idname = "paint.curve_stroke_copy_ramp"
    bl_label = "Copy Ramp"
    bl_description = "Copy this curve's color ramp, to paste onto another curve"

    @classmethod
    def poll(cls, context):
        curve_obj = context.active_object
        return (
            curve_obj is not None and curve_obj.type == 'CURVE'
            and curve_obj.curve_paint_settings.profile_ramp_texture is not None
        )

    def execute(self, context):
        global _ramp_clipboard
        _ramp_clipboard = context.active_object.curve_paint_settings.profile_ramp_texture
        self.report({'INFO'}, "Ramp copied")
        return {'FINISHED'}


class CURVEPAINT_OT_paste_ramp(Operator):
    bl_idname = "paint.curve_stroke_paste_ramp"
    bl_label = "Paste Ramp"
    bl_description = "Paste the copied color ramp onto this curve, as an independent copy"

    @classmethod
    def poll(cls, context):
        curve_obj = context.active_object
        return curve_obj is not None and curve_obj.type == 'CURVE' and _ramp_clipboard is not None

    def execute(self, context):
        curve_obj = context.active_object
        props = curve_obj.curve_paint_settings
        new_tex = _ramp_clipboard.copy()
        new_tex.name = f"{curve_obj.name}_CurvePaintRamp"
        new_tex.use_fake_user = True
        props.profile_ramp_texture = new_tex
        self.report({'INFO'}, "Ramp pasted (independent copy)")
        return {'FINISHED'}


# Each preset: (interpolation, [(position, value), ...], mapping). Stops
# authored for Mirror mapping assume position 0 is the curve's centerline,
# position 1 is the profile's outer edge; Full Width presets (Bevel) are
# inherently asymmetric and use the whole 0..1 span directly instead.
# Direction (Raise/Indent/Both) handles the sign separately, so these only
# need to vary shape, not polarity.
RAMP_PRESETS = {
    'SMOOTH': ('EASE', [(0.0, 1.0), (1.0, 0.0)], 'MIRROR'),
    'SHARP': ('LINEAR', [(0.0, 1.0), (1.0, 0.0)], 'MIRROR'),
    'FLAT_TOP': ('LINEAR', [(0.0, 1.0), (0.4, 1.0), (1.0, 0.0)], 'MIRROR'),
    'STEP': ('CONSTANT', [(0.0, 1.0), (0.5, 0.0)], 'MIRROR'),
    'RAIL': ('LINEAR', [(0.0, 0.5), (0.5, 1.0), (1.0, 0.5)], 'MIRROR'),
    'COVED': ('EASE', [(0.0, 1.0), (0.4, 1.0), (1.0, 0.0)], 'MIRROR'),
    'BEVEL': ('LINEAR', [(0.0, 1.0), (0.6, 1.0), (1.0, 0.0)], 'FULL'),
}


class CURVEPAINT_OT_apply_ramp_preset(Operator):
    bl_idname = "paint.curve_stroke_apply_ramp_preset"
    bl_label = "Apply Ramp Preset"
    bl_description = "Replace this curve's color ramp with a simple preset shape"
    bl_options = {'REGISTER', 'UNDO'}

    preset: EnumProperty(
        name="Preset",
        items=[
            ('SMOOTH', "Smooth", "Soft, rounded peak at the centerline"),
            ('SHARP', "Sharp", "Hard, angular peak at the centerline"),
            ('FLAT_TOP', "Flat Top", "Plateau at the centerline with sloped shoulders"),
            ('STEP', "Step", "Hard-edged band, no falloff until a sudden cutoff"),
            ('RAIL', "Rail", "Twin ridges flanking a neutral channel at the centerline"),
            ('COVED', "Coved", "Flat Top with softly rounded shoulders instead of hard corners"),
            ('BEVEL', "Bevel", "Flat on one side, sloped to neutral on the other (asymmetric, Full Width)"),
        ],
    )

    @classmethod
    def poll(cls, context):
        curve_obj = context.active_object
        return curve_obj is not None and curve_obj.type == 'CURVE'

    def execute(self, context):
        curve_obj = context.active_object
        props = curve_obj.curve_paint_settings

        if props.profile_ramp_texture is None:
            tex = bpy.data.textures.new(f"{curve_obj.name}_CurvePaintRamp", type='BLEND')
            tex.use_color_ramp = True
            tex.use_fake_user = True
            props.profile_ramp_texture = tex

        ramp = props.profile_ramp_texture.color_ramp
        interpolation, stops, mapping = RAMP_PRESETS[self.preset]

        while len(ramp.elements) > 1:
            ramp.elements.remove(ramp.elements[-1])

        ramp.interpolation = interpolation
        first_pos, first_val = stops[0]
        ramp.elements[0].position = first_pos
        ramp.elements[0].color = (first_val, first_val, first_val, 1.0)
        for pos, val in stops[1:]:
            elem = ramp.elements.new(pos)
            elem.color = (val, val, val, 1.0)

        props.ramp_mapping = mapping
        props.profile_source = 'RAMP'

        self.report({'INFO'}, f"Applied '{self.preset.title()}' ramp preset")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Properties + Panel
# ---------------------------------------------------------------------------

# Blend Mode's available options depend on Direction. Under Raise or Indent,
# every value already shares one sign, which makes Max/Min/Greatest
# Deviation either exactly duplicate Add or become permanent no-ops, so
# they're only offered under Both, where they're genuinely distinct.
# Defined as module-level constants (not rebuilt inside the callback) since
# Blender's dynamic-items callbacks need the returned strings to stay alive
# beyond the call: recreating them each time risks a use-after-free crash.
_BLEND_MODE_BASE_ITEMS = (
    ('MIX', "Mix", "Blend toward the sampled value"),
    ('ADD', "Add", "Accumulate, raising or lowering"),
    ('AVERAGE', "Average", "Settle toward the midpoint of old and new, gentler than Add for a single crossing"),
)
_BLEND_MODE_BOTH_ONLY_ITEMS = (
    ('MAX', "Lighten (Max)", "Only ever raises; avoids double-stacking raised details"),
    ('MIN', "Darken (Min)", "Only ever lowers; avoids double-stacking grooves"),
    ('DEVIATION', "Greatest Deviation", "Keeps whichever effect is stronger, regardless of direction"),
)
_BLEND_MODE_ALL_ITEMS = _BLEND_MODE_BASE_ITEMS + _BLEND_MODE_BOTH_ONLY_ITEMS


def _blend_mode_items(self, context):
    if self.profile_direction == 'BOTH':
        return _BLEND_MODE_ALL_ITEMS
    return _BLEND_MODE_BASE_ITEMS


class CurvePaintProperties(PropertyGroup):
    """Lives on the curve object itself (Object.curve_paint_settings), so
    each curve remembers its own target and profile settings permanently."""
    target_obj: PointerProperty(
        name="Target",
        description="Mesh object whose UV space we're writing into",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH',
    )
    target_image: PointerProperty(
        name="Image",
        description="Image to write height/normal detail into (use Non-Color colorspace)",
        type=bpy.types.Image,
    )
    resample_distance: FloatProperty(
        name="Curve Fidelity",
        description="How finely to sample the curve's own shape; lower tracks tight bends more accurately",
        default=0.01,
        min=0.0001,
        soft_max=0.5,
        unit='LENGTH',
    )
    profile_source: EnumProperty(
        name="Source",
        description="What shapes the cross-section",
        items=[
            ('RAMP', "Color Ramp", "An editable ramp for the cross-section shape, no length variation"),
            ('IMAGE', "Image", "A grayscale image, with alpha as coverage"),
        ],
        default='RAMP',
    )
    profile_image: PointerProperty(
        name="Image",
        description="Grayscale image sampled across the curve; alpha (if present) acts as coverage",
        type=bpy.types.Image,
    )
    use_alpha: BoolProperty(
        name="Use Alpha",
        description=(
            "Treat the profile's alpha channel as a strength multiplier "
            "(coverage): alpha 0 means no effect there regardless of the "
            "height value. When off, alpha is ignored and treated as fully "
            "opaque everywhere"
        ),
        default=True,
    )
    profile_ramp_texture: PointerProperty(
        name="Ramp Host",
        description="Internal, hosts this curve's color ramp",
        type=bpy.types.Texture,
    )
    ramp_mapping: EnumProperty(
        name="Mapping",
        description="How the ramp maps across the profile's width",
        items=[
            ('FULL', "Full Width", "The ramp spans edge to edge, can be asymmetric"),
            ('MIRROR', "Mirrored", "The ramp defines one side (center to edge), reflected for the other"),
        ],
        default='FULL',
    )
    profile_rotate_90: BoolProperty(
        name="Rotate 90°",
        description="Swap the image's axes, for when the source image was authored sideways",
        default=False,
    )
    profile_half_width: FloatProperty(
        name="Half Width",
        description="Distance from the curve's centerline to each edge of the profile",
        default=0.02,
        min=0.0001,
        soft_max=0.5,
        unit='LENGTH',
    )
    profile_mode: EnumProperty(
        name="Mode",
        items=[
            ('STRETCH', "Stretch", "Map the profile once across the entire curve"),
            ('STAMP', "Stamp", "Repeat the profile at even spacing along the curve"),
        ],
        default='STRETCH',
    )
    profile_spacing: FloatProperty(
        name="Spacing",
        description="Distance between stamps.",
        default=0.05,
        min=0.0001,
        unit='LENGTH',
    )
    profile_lock_stamp_ratio: BoolProperty(
        name="Use Image Ratio",
        description="Use image's width:height ratio for sizing.",
        default=True,
    )
    profile_stamp_size: FloatProperty(
        name="Stamp Size",
        description=(
            "Length of stamp along the curve."
        ),
        default=0.025,
        min=0.0001,
        unit='LENGTH',
    )
    profile_strength: FloatProperty(
        name="Strength",
        default=1.0,
        min=0.0,
        soft_max=4.0,
    )
    profile_quality: EnumProperty(
        name="Quality",
        description=(
            "Sub-samples averaged per output pixel. Higher reduces jagged "
            "edges and inconsistent strength on stretched UVs, at a "
            "proportional cost in compute time"
        ),
        items=[
            ('1', "1×1 (Fast)", "One sample per pixel, fastest"),
            ('2', "2×2", "4 samples per pixel, averaged, good balance"),
            ('3', "3×3", "9 samples per pixel, averaged, highest quality, slowest"),
        ],
        default='2',
    )
    profile_direction: EnumProperty(
        name="Direction",
        description="Which way the profile's sampled value drives the stroke",
        items=[
            ('RAISE', "Raise", "Profile treated as 0 = no effect, 1 = full raise"),
            ('BOTH', "Both", "Values above 0.5 raise, below 0.5 lower "),
            ('INDENT', "Indent", "Profile treated as 0 = no effect, 1 = full indent"),
        ],
        default='RAISE',
    )
    edge_feather: FloatProperty(
        name="Edge Feather",
        description="Applied as fraction of the half-width over which strength tapers to zero at boundary",
        default=0.06,
        min=0.0,
        max=0.5,
    )
    blend_mode: EnumProperty(
        name="Blend",
        items=_blend_mode_items,
    )
    cap_style: EnumProperty(
        name="Cap Style",
        description="Shape of the curve's start and end",
        items=[
            ('ROUND', "Round", "Rounded, capsule-style ends"),
            ('FLAT', "Flat", "Just flat"),
        ],
        default='ROUND',
    )
    relax_curve: BoolProperty(
        name="Relax Curve",
        description=(
            "Laplacian smoothing applied to the curve before sampling, "
            "averaging points to reduce jitter (e.g. from a Shrinkwrap source)"
        ),
        default=False,
    )
    relax_iterations: IntProperty(
        name="Iterations",
        description="Passes to apply. Higher removes more jitter but can also soften intentional shape",
        default=3,
        min=1,
        max=20,
    )
    blur_size: FloatProperty(
        name="Size (px)",
        description=(
            "How many neighboring pixels blend together. Higher reaches "
            "further and blurs more, but costs more to compute"
        ),
        default=2.0,
        min=0.0,
        soft_max=20.0,
    )
    blend_margin: FloatProperty(
        name="Blend Margin",
        description=(
            "How far past the stroke's own edge the blur reaches, fading "
            "to nothing. Lets the stroke blend into its surroundings "
            "instead of stopping at a hard edge"
        ),
        default=0.01,
        min=0.0,
        soft_max=0.1,
        unit='LENGTH',
    )
    blur_strength: FloatProperty(
        name="Strength",
        description="Overall blend amount toward the blurred result",
        default=1.0,
        min=0.0,
        max=1.0,
    )
    blur_mask_mode: EnumProperty(
        name="Mask",
        description="Where the blur applies within the stroke",
        items=[
            ('EDGES', "Edges Only", "Only blurs near the width boundary, tapering inward"),
            ('UNIFORM', "Uniform", "Blurs evenly across the whole stroke"),
        ],
        default='EDGES',
    )
    blur_edge_threshold: FloatProperty(
        name="Edge Threshold",
        description="Distance from center (as a fraction of half-width) where the edge blur starts",
        default=0.6,
        min=0.0,
        max=0.99,
    )
    blur_auto_apply: BoolProperty(
        name="Auto-Apply After Paint",
        description="Automatically run the blur pass right after Draw",
        default=False,
    )


class CURVEPAINT_PT_panel(Panel):
    bl_label = "Path to Normalcy"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "P2N"

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout
        curve_obj = context.active_object

        selected_curves = [o for o in context.selected_objects if o.type == 'CURVE']
        if len(selected_curves) > 1:
            layout.label(text=f"{len(selected_curves)} curves selected", icon='CURVE_DATA')
            row = layout.row(align=True)
            row.operator("paint.curve_stroke_paint_selected", icon='BRUSH_DATA', text="Paint Selected")
            row.operator("paint.curve_stroke_undo_selected", icon='LOOP_BACK', text="Undo Selected")
            return

        if curve_obj is None or curve_obj.type != 'CURVE':
            layout.label(text="Select a curve to edit its settings", icon='INFO')
            return

        props = curve_obj.curve_paint_settings

        layout.label(text=f"Curve: {curve_obj.name}", icon='CURVE_DATA')

        col = layout.column(align=True)
        col.prop(props, "target_obj")
        col.prop(props, "target_image")

        layout.prop(props, "resample_distance")

        split = layout.split(factor=0.5, align=True)
        split.label(text="Cap Style")
        split.prop(props, "cap_style", text="")

        layout.row().prop(props, "profile_mode", expand=True)
        layout.row().prop(props, "profile_source", expand=True)

        box = layout.box()
        if props.profile_source == 'IMAGE':
            box.prop(props, "profile_image")
        elif props.profile_source == 'RAMP':
            split = box.split(factor=0.5, align=True)
            split.label(text="Mapping")
            split.prop(props, "ramp_mapping", text="")
            box.operator_menu_enum(
                "paint.curve_stroke_apply_ramp_preset", "preset", text="Presets", icon='PRESET'
            )
            if props.profile_ramp_texture is None:
                row = box.row(align=True)
                row.operator("paint.curve_stroke_add_ramp", icon='ADD', text="Add")
                row.operator("paint.curve_stroke_paste_ramp", icon='PASTEDOWN', text="Paste")
            else:
                box.template_color_ramp(props.profile_ramp_texture, "color_ramp", expand=True)
                row = box.row(align=True)
                row.operator("paint.curve_stroke_copy_ramp", icon='COPYDOWN', text="Copy")
                row.operator("paint.curve_stroke_paste_ramp", icon='PASTEDOWN', text="Paste")

        split = box.split(factor=0.75, align=True)
        split.prop(props, "use_alpha")
        if props.profile_source == 'IMAGE':
            split.prop(props, "profile_rotate_90", text="", icon='CON_ROTLIKE', toggle=True)

        if props.profile_source == 'IMAGE' and props.profile_mode == 'STAMP':
            box.prop(props, "profile_lock_stamp_ratio")

        box.prop(props, "profile_half_width")
        if props.profile_mode == 'STAMP':
            box.prop(props, "profile_spacing")
            if props.profile_source == 'IMAGE':
                if not props.profile_lock_stamp_ratio:
                    box.prop(props, "profile_stamp_size")
            else:
                box.prop(props, "profile_stamp_size")
        box.prop(props, "profile_strength")
        box.prop(props, "edge_feather")

        split = box.split(factor=0.5, align=True)
        split.label(text="Quality")
        split.prop(props, "profile_quality", text="")

        split = box.split(factor=0.5, align=True)
        split.label(text="Direction")
        split.prop(props, "profile_direction", text="")

        split = box.split(factor=0.5, align=True)
        split.label(text="Blend")
        split.prop(props, "blend_mode", text="")

        layout.separator()
        row = layout.row(align=True)
        row.operator("paint.curve_stroke", icon='BRUSH_DATA', text="Draw")
        row.operator("paint.curve_stroke_redraw", icon='FILE_REFRESH', text="Redraw")
        layout.operator("paint.curve_stroke_undo", icon='LOOP_BACK')

        blur_header, blur_box = layout.panel("curve_paint_blur_pass", default_closed=True)
        blur_header.label(text="Blur Pass", icon='NODE_TEXTURE')
        if blur_box:
            blur_box.prop(props, "blur_mask_mode")
            if props.blur_mask_mode == 'EDGES':
                blur_box.prop(props, "blur_edge_threshold")
            blur_box.prop(props, "blur_size")
            blur_box.prop(props, "blend_margin")
            blur_box.prop(props, "blur_strength")
            blur_box.prop(props, "blur_auto_apply")
            blur_box.operator("paint.curve_stroke_blur", icon='MOD_SMOOTH')

        relax_header, relax_box = layout.panel("curve_paint_relax", default_closed=True)
        relax_header.label(text="Relax Curve", icon='MOD_SMOOTH')
        if relax_box:
            relax_box.prop(props, "relax_curve")
            row = relax_box.row(align=True)
            row.label(text="For jittery curves", icon='INFO')
            if props.relax_curve:
                relax_box.prop(props, "relax_iterations")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    CurvePaintProperties,
    CURVEPAINT_OT_stroke,
    CURVEPAINT_OT_blur,
    CURVEPAINT_OT_undo,
    CURVEPAINT_OT_redraw,
    CURVEPAINT_OT_paint_selected,
    CURVEPAINT_OT_undo_selected,
    CURVEPAINT_OT_add_ramp,
    CURVEPAINT_OT_copy_ramp,
    CURVEPAINT_OT_paste_ramp,
    CURVEPAINT_OT_apply_ramp_preset,
    CURVEPAINT_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.curve_paint_settings = PointerProperty(type=CurvePaintProperties)


def unregister():
    del bpy.types.Object.curve_paint_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
